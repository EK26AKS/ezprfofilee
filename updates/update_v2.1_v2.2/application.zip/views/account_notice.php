<!DOCTYPE html>
<html style="height:100%">
<head><title> Account Notice</title>
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/default/css/bootstrap.css"/>
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/default/css/style.css"/>
	<link rel="stylesheet" href="<?php echo base_url() ?>assets/default/icon-fonts/font-awesome-4.7.0/css/font-awesome.min.css"/>
</head>

<body style="color: #444; margin:0;font: normal 14px/20px Arial, Helvetica, sans-serif; height:100%; background-color: #fff;">

	<div style="height:auto; min-height:100%; ">     
		<div style="text-align: center; width:800px; margin-left: -400px; position:absolute; top: 30%; left:50%;">
			<h2 style="margin-top:20px;font-size: 30px;"><i class="fa fa-eye-slash fa-2x" aria-hidden="true"></i></h2>
			<h5>This profile is currently not available</h5> <br>
			<a href="<?php echo base_url() ?>" class="btn btn-primary"> <i class="fa fa-long-arrow-left" aria-hidden="true"></i> Back to Home </a>
		</div>
        
        
	</div>

	<script src="<?php echo base_url() ?>assets/default/js/jquery-2.1.4.min.js"></script> 
	<script src="<?php echo base_url() ?>assets/default/js/jquery.cubeportfolio.min.js"></script>
	<script src="<?php echo base_url() ?>assets/default/js/bootstrap.min.js"></script> 


</body>
</html>